/** @type {import(tailwindcss).config} */
module.exports = {
    content: ["./**/*.{html,js}"],
    theme: {
      extend: {
        backgroundImage: {
          "home": "url('')"
        }
      },
    },
    plugins: [],
  }